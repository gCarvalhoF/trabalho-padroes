package br.edu.ifba.inf011.model.player;

public enum PlayerMode {
	
	PlayerAll, RepeatAll, RandomMode

}
