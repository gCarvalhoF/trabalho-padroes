package br.edu.ifba.inf011.model.player;

public interface PlayerObserver {
    void update(Player player);
}