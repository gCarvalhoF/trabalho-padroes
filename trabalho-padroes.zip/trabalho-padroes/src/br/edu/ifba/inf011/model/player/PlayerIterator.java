package br.edu.ifba.inf011.model.player;

public interface PlayerIterator {

    boolean temProximo();

    Playable proximo();
}
